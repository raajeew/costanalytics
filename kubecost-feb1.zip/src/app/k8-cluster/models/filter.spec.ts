import { Filter } from './filter';

describe('Filter', () => {
  it('should create an instance', () => {
    expect(new Filter()).toBeTruthy();
  });
});
