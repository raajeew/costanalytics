export class Graph {
}
