import { Query } from './query';

describe('Query', () => {
  it('should create an instance', () => {
    expect(new Query()).toBeTruthy();
  });
});
