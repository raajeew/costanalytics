export class Filter {
    key: string;
    values: string[];
}
