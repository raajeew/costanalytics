import { GroupTab } from './group-tab';

describe('GroupTab', () => {
  it('should create an instance', () => {
    expect(new GroupTab()).toBeTruthy();
  });
});
