import { DataGrid } from './data-grid';

describe('DataGrid', () => {
  it('should create an instance', () => {
    expect(new DataGrid()).toBeTruthy();
  });
});
