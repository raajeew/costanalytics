import { Snapshot } from './snapshot';

describe('Snapshot', () => {
  it('should create an instance', () => {
    expect(new Snapshot()).toBeTruthy();
  });
});
